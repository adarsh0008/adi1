<?php
/**
 * Preload Template: spinner pulse
 *
 * @package Thim_Starter_Theme
 */
?>

<div class="sk-spinner sk-spinner-pulse"></div>