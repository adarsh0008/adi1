<?php
/**
 * Preload Template: double bounce
 *
 * @package Thim_Starter_Theme
 */
?>

<div class="sk-double-bounce">
	<div class="sk-child sk-double-bounce1"></div>
	<div class="sk-child sk-double-bounce2"></div>
</div>