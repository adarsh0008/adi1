<?php
thim_customizer()->add_panel(
	array(
		'id'       => 'nav_menus',
		'priority' => 90,
		'title'    => esc_html__( 'Menus', 'course-builder' ),
		'icon'     => 'dashicons-menu'
	)
);
