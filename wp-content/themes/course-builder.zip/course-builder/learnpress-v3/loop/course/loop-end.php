<?php
/**
 * Template for display wrap end of courses list
 *
 * @author  ThimPress
 * @version 3.0.0
 */
?>
</div>