/*
jQuery( document ).ajaxComplete(function() {


		var possible_slider = jQuery('#ttshowcase_0 div.ttshowcase_slider');
		console.log(possible_slider);
		if(possible_slider.length	> 0) {

			possible_slider.show('slow');
			console.log('slider exists');

		}	

	});

	*/